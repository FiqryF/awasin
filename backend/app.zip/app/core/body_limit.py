from app.core.exceptions import error_response


class RequestBodyLimit:
    """Bound actual bytes, including chunked requests, before JSON parsing."""
    def __init__(self, app, prefix):
        self.app, self.prefix = app, prefix

    async def __call__(self, scope, receive, send):
        if (scope['type'] != 'http' or not scope['path'].startswith(self.prefix + '/')
                or scope['method'] not in {'POST', 'PATCH', 'PUT', 'DELETE'}):
            return await self.app(scope, receive, send)
        path = scope['path'].rstrip('/')
        # The analysis media handler streams with a mode-specific cap and admission limit.
        media_path = self.prefix + '/analysis/media/'
        if scope['method'] == 'POST' and path.startswith(media_path) and path[len(media_path):] in {'message', 'qr', 'image', 'video'}:
            return await self.app(scope, receive, send)
        limit = 32768 if path == self.prefix + '/feedback' else 262144
        if path == self.prefix + '/analysis/explanation':
            limit = 1024
        chunks, size = [], 0
        while True:
            message = await receive()
            if message['type'] == 'http.disconnect':
                return
            body = message.get('body', b'')
            size += len(body)
            if size > limit:
                return await error_response(413, 'request_too_large', 'Request too large')(scope, receive, send)
            if body:
                chunks.append(body)
            if not message.get('more_body', False):
                break
        consumed = False

        async def limited_receive():
            nonlocal consumed
            if not consumed:
                consumed = True
                return {'type': 'http.request', 'body': b''.join(chunks), 'more_body': False}
            return await receive()
        return await self.app(scope, limited_receive, send)
