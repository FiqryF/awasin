"""AWASIN backend foundation."""
